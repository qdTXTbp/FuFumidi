# -*- coding: utf-8 -*-
"""
MSST 音频分离引擎
==================
基于 pymss（原 MSST 推理库的官方封装）加载 MSST / VR 模型进行音轨分离，
支持 bs_roformer / mel_band_roformer / htdemucs / mdx23c / scnet /
bandit / apollo / vr 等架构。

参数（对齐 MSST-WebUI 语义，无预设体系）：
  chunk_size    分块大小（样本数，建议 44100 整数倍；增大提高分离效果，但增加耗时与显存）
  num_overlap   重叠数 N → step = chunk_size // N（增大提高分离效果，但增加耗时，建议 4）
  batch_size    批次大小（减小可降低显存占用，对效果影响不大）
  normalize     音频归一化（输入/输出统一缩放；部分模型无此功能）
  use_tta       TTA 测试时增强（小幅提升质量，推理时间 ×3）
  stems         输出音轨列表（不同模型可输出的音轨不同；缺省输出全部）
  output_format wav / flac / mp3（默认 wav）

实时输出：progress_cb(percent) 0~100（含 TTA 各 pass 合并）
依赖：pymss==2.0.1
"""

import os
import tempfile
import time


def available():
    """pymss（MSST 分离引擎）是否可用。"""
    try:
        import pymss  # noqa: F401
        return True
    except Exception:
        return False


# 模型文件名/架构推断出的家族 → pymss model_type
_ARCH_TABLE = {
    "mdx23c": "mdx23c",
    "htdemucs": "htdemucs",
    "htdemucsvocals": "htdemucs",
    "htdemucsftbass": "htdemucs",
    "htdemucsftdrums": "htdemucs",
    "drumsep": "htdemucs",
    "scnet": "scnet",
    "apollo": "apollo",
    "bandit": "bandit_v2",
    "melbandroformer": "mel_band_roformer",
    "bsroformer": "bs_roformer",
    "uvr": "vr",
    "vr": "vr",
    "uvrvr": "vr",
}


def model_type_for(arch):
    """把架构名（models.js 的 arch 字段）映射为 pymss 支持的 model_type；不支持返回 None。"""
    key = "".join(ch for ch in str(arch or "").lower() if ch.isalnum())
    return _ARCH_TABLE.get(key)


def _log(cb, msg):
    if cb:
        try:
            cb(msg)
        except Exception:
            pass


def _emit(progress_cb, percent):
    if progress_cb:
        try:
            progress_cb(max(0.0, min(100.0, percent)))
        except Exception:
            pass


# ---------------------------------------------------------------------------
# 分块进度捕获：pymss 内部用 tqdm(total=mix.shape[1]) 逐块 update，
# 我们替换 pymss 命名空间里的 tqdm 为捕获类，把进度透传给外部回调。
# TTA 有多个 pass（每个 pass 一条进度条），按 pass 叠加成整体单调进度。
# ---------------------------------------------------------------------------
_PASS_TOTAL = 1           # 由调用方在跑之前设置（use_tta ? 3 : 1）


def _quiet_pymss_logger():
    """压制 pymss 的 INFO 日志：其一避免跨盘符(不同 mount)时其 logger 内部
    os.path.relpath 抛 ValueError；其二避免刷屏。真实进度走 progress_cb。"""
    try:
        import logging
        from pymss.logger import get_separation_logger
        get_separation_logger().setLevel(logging.WARNING)
    except Exception:
        pass


class _CaptureBar:
    _created = 0

    def __init__(self, iterable=None, total=None, desc=None, **kwargs):
        _CaptureBar._created += 1
        self.pass_index = _CaptureBar._created - 1
        self.total = 0.0
        if total is not None:
            self.total = float(total)
        elif iterable is not None:
            try:
                self.total = float(len(iterable))
            except Exception:
                self.total = 0.0
        self.n = 0.0

    def reset(self, total=None, *a, **k):
        if total is not None:
            self.total = float(total)
        self.n = 0.0

    def update(self, n=1):
        self.n += float(n)
        self.refresh()

    def refresh(self, *a, **k):
        pass

    def close(self):
        pass

    def set_postfix(self, *a, **k):
        pass

    @property
    def format_dict(self):
        return {"n": self.n, "total": self.total}

    def __iter__(self):
        return iter(self._iterable if hasattr(self, "_iterable") and self._iterable is not None else [])

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def __str__(self):
        return ""

    def __del__(self):
        pass


def _install_progress(progress_cb):
    P = max(1, _PASS_TOTAL)

    def _push(self):
        frac = (self.pass_index + self.n / max(1.0, self.total)) / P
        _emit(progress_cb, frac * 100.0)

    _CaptureBar.refresh = _push
    _CaptureBar.close = _push

    # 替换 pymss 命名空间内已绑定的 tqdm 引用（demix / separator）
    import pymss.utils as _pu
    import pymss.separator as _ps
    _old_utils = getattr(_pu, "tqdm", None)
    _old_sep = getattr(_ps, "tqdm", None)
    _pu.tqdm = _CaptureBar
    _ps.tqdm = _CaptureBar
    # 兼容 tqdm.auto / tqdm.std（pymss 模型内部可能有别的调用点）
    try:
        import tqdm as _mtq
        import tqdm.auto as _ata
        _old_auto = getattr(_ata, "tqdm", _old_utils)
        _old_tq = _mtq.tqdm
        _ata.tqdm = _CaptureBar
        _mtq.tqdm = _CaptureBar
    except Exception:
        _old_auto = None
        _old_tq = None

    return lambda: _restore_tqdm(_pu, _ps, _old_utils, _old_sep, _old_auto, _old_tq)


def _restore_tqdm(_pu, _ps, _old_utils, _old_sep, _old_auto, _old_tq):
    try:
        if _old_utils is not None:
            _pu.tqdm = _old_utils
        if _old_sep is not None:
            _ps.tqdm = _old_sep
        if _old_auto is not None:
            import tqdm.auto as _ata
            _ata.tqdm = _old_auto
        if _old_tq is not None:
            import tqdm as _mtq
            _mtq.tqdm = _old_tq
    except Exception:
        pass


def separate(audio_path, out_dir, params=None, log_cb=None, progress_cb=None):
    """对单个音频文件做 MSST 分离，把所选音轨写入 out_dir，返回输出文件路径列表。

    参数来自前端；模型文件、配置路径、架构由主进程解析后经 params 传入：
      params["model_path"]   模型 .ckpt 绝对路径
      params["config_path"]  对应 .yaml 配置绝对路径（vr 可缺省）
      params["arch"]         架构名（用于推导 model_type）
      params["output_dir"]   输出目录（等同 out_dir）
    """
    from pymss.separator import MSSeparator
    from pymss.audio_io import load_audio, save_audio

    params = params or {}
    if not available():
        raise RuntimeError(
            "未检测到 pymss（MSST 分离引擎）。\n内置的音频分离引擎未加载，请重新安装 AudioMuse。"
        )
    _quiet_pymss_logger()

    model_path = params.get("model_path") or ""
    config_path = params.get("config_path") or None
    arch = params.get("arch") or ""
    model_type = model_type_for(arch)
    if not model_type:
        raise RuntimeError(
            f"该模型的架构「{arch or '未知'}」暂不支持。\n"
            "已支持的架构：BS-Roformer / Mel-Band Roformer / HTDemucs / MDX23C / "
            "SCNet / Bandit / Apollo / UVR。请更换模型后重试。"
        )
    if not model_path or not os.path.isfile(model_path):
        raise RuntimeError("未找到模型文件，请先在模型管理中下载所选模型。")
    # ★ 仓库里没带 .yaml 的模型不再直接判死：按权重自动生成配置并**跑一次 1 秒前向**校验，
    #   过了就用（缓存在 cache/msst_autocfg，只生成一次）；没过才照旧报错。
    #   为什么必须跑前向：pymss 用 load_state_dict(..., assign=True) 会跳过形状校验，
    #   "装上了"不等于"能用"（见 engine/msst_autoconfig.py 顶部说明）。
    if model_type != "vr" and (not config_path or not os.path.isfile(config_path)):
        try:
            import msst_autoconfig as _autocfg
            _log(log_cb, "该模型没有现成配置，正在按权重自动生成并校验（首次会慢一点）…")
            _t_auto = time.time()
            _auto = _autocfg.ensure_config(model_path, arch, log_cb)
            if _auto:
                config_path = _auto
                _log(log_cb, "自动配置通过前向校验（%.1fs）" % (time.time() - _t_auto))
        except Exception as _e:
            _log(log_cb, "自动配置失败：%s" % _e)
    if model_type != "vr" and (not config_path or not os.path.isfile(config_path)):
        raise RuntimeError("未找到该模型的配置文件（yaml 缺失），自动生成也没通过校验，暂不支持此模型。")

    output_format = str(params.get("output_format") or "wav").lower().lstrip(".")
    if output_format not in ("wav", "flac", "mp3"):
        output_format = "wav"

    os.makedirs(out_dir, exist_ok=True)

    # ---- 推理参数（对齐 MSST-WebUI）----
    sr = 44100
    chunk_size = int(params.get("chunk_size") or 0)
    if chunk_size <= 0:
        chunk_size = 926100  # 21s，BS-Roformer 常见默认
    num_overlap = int(params.get("num_overlap") or 4)
    if num_overlap < 1:
        num_overlap = 1
    step = max(1, int(chunk_size // num_overlap))
    overlap_size = chunk_size - step          # pymss 用 overlap_size；等价于 MSST 的 step=C//N
    batch_size = max(1, int(params.get("batch_size") or 2))
    normalize = bool(params.get("normalize"))
    use_tta = bool(params.get("use_tta"))
    selected = params.get("stems") or None
    if isinstance(selected, str):
        selected = [s for s in selected.split(",") if s.strip()]

    global _PASS_TOTAL, _CaptureBar
    _PASS_TOTAL = 3 if use_tta else 1
    _CaptureBar._created = 0

    # ★ issue #20：pymss 的 device="auto" 只看 `torch.cuda.is_available()`，而**算力不匹配**
    #   的机器上它照样为 True（驱动认卡），于是 pymss 会挑 cuda:0，再在推理中途抛
    #   `no kernel image is available`。engine_gpu.torch_device() 已经把这种情况判成 cpu，
    #   这里显式跟随。（只认 cuda / mps，其余一律 cpu —— 与 pymss 的合法取值一致；
    #   拿不到 engine_gpu 时保留 "auto" 的旧行为，避免误伤正常 GPU 机器。）
    # ★ 2026-10-18：DirectML（AMD/Intel 走 torch_directml）之前被这行**无条件降级成 cpu** ——
    #   体检里明明写着"加速已启用：DirectML GPU（privateuseone:0）"、算力校验也过，
    #   分离却仍然打"未检测到可用的 GPU 加速"，然后在 CPU 上跑到超时（用户实测 19 分钟超时失败）。
    #   现在：DirectML 设备先**真跑一次矩阵乘**验证可用，可用就交给 pymss；
    #   不可用（或拿不到设备）再退回 cpu。cuda/mps 的行为完全不变。
    def _directml_usable(dev):
        try:
            import torch
            import torch_directml  # noqa: F401  仅确认扩展在
            a = torch.ones(64, 64).to(dev)
            b = torch.ones(64, 64).to(dev)
            c = (a @ b).to("cpu")
            return bool(torch.isfinite(c).all().item()) and abs(float(c[0, 0]) - 64.0) < 1e-3
        except Exception:
            return False

    _sep_dev = "auto"
    try:
        from engine_gpu import torch_device as _torch_device
        _d = _torch_device()
        if _d in ("cuda", "mps"):
            _sep_dev = _d
        elif _d and _d.startswith("privateuseone"):
            _sep_dev = _d if _directml_usable(_d) else "cpu"
        else:
            _sep_dev = "cpu"
    except Exception:
        _sep_dev = "auto"

    restore = None
    start = time.time()
    try:
        _log(log_cb, f"加载 MSST 模型（{arch} / {os.path.basename(model_path)}）…")
        if _sep_dev == "cpu":
            _log(log_cb, "分离将使用 CPU（未检测到可用的 GPU 加速，速度较慢）")
        elif _sep_dev != "auto":
            _log(log_cb, f"分离将使用 GPU 加速：{_sep_dev}")
        separator = MSSeparator(
            model_type=model_type,
            model_path=model_path,
            config_path=config_path,
            device=_sep_dev,
            device_ids=[0],
            output_format=output_format,
            use_tta=use_tta,
            store_dirs=out_dir,
            inference_params={
                "batch_size": batch_size,
                "overlap_size": overlap_size,
                "chunk_size": chunk_size,
                "normalize": None if model_type == "vr" else normalize,
            },
        )
        _log(log_cb, "模型加载完成，开始分离…")

        instruments = list(separator.config.training.instruments)
        _log(log_cb, "可输出音轨：" + " / ".join(instruments))

        # 校验/过滤前端勾选的音轨：只保留本模型实际存在的音轨，避免非法键报错
        if selected:
            valid_low = {str(i).lower(): i for i in instruments}
            filtered = [valid_low[s.lower()] for s in selected if str(s).lower() in valid_low]
            if filtered != selected:
                dropped = [s for s in selected if str(s).lower() not in valid_low]
                _log(log_cb, "· 忽略无效音轨：" + " / ".join(dropped))
            selected = list(dict.fromkeys(filtered)) or None

        # 安装分块进度捕获
        restore = _install_progress(progress_cb)

        mix, sr = load_audio(os.path.abspath(audio_path), sr=sr, mono=False)
        if mix.ndim == 2 and mix.shape[0] > 2:
            mix = np_mean_channels(mix)

        # 若前端传了 stems，仅分离并保留这些音轨
        try:
            results = separator.separate(mix, pbar=True, stems=selected)
        except Exception as _sep_err:
            # 运行期 CUDA 报错（算力/驱动/显存）→ 附一句可操作的话，别让用户只看到英文原始错误
            try:
                from engine_gpu import cuda_error_kind as _kind, cuda_error_hint as _hint
                _k = _kind(_sep_err)
                if _k and _k != "oom":
                    _log(log_cb, _hint(_k) + "（GPU 加速可在「设置 → GPU」中关闭，关闭后本次分离会改用 CPU）")
            except Exception:
                pass
            raise

        base = os.path.splitext(os.path.basename(audio_path))[0]
        outputs = []
        audio_params = {
            "wav_bit_depth": "FLOAT",
            "flac_bit_depth": "PCM_24",
            "mp3_bit_rate": "320k",
            "m4a_bit_rate": "192k",
            "m4a_aac_at_quality": 2,
        }
        for stem, audio in results.items():
            save_dir = os.path.join(out_dir, f"{base}_{stem}.{output_format}")
            save_audio(save_dir, audio, sr, output_format, audio_params)
            outputs.append(save_dir)
            _log(log_cb, f"· 已输出音轨「{stem}」→ {os.path.basename(save_dir)}")

        # ★ 单轨降噪模型（training.target_instrument 非空，如 au*r*33 denoise_*）的「clean」
        #   在设计上就是**尽量保留音乐、只压稳态噪声**：对音乐为主的素材，输出与原始音频
        #   几乎完全相同是正常的，不是分离失败。但用户看到「clean 和原音一样」会以为坏了，
        #   所以这里做一次相似度检查并把话说清楚（2026-10-17 用户实测反馈）。
        try:
            target = separator.config.training.target_instrument
        except Exception:
            target = None
        if target and target in results:
            try:
                import numpy as _np
                a = _np.asarray(results[target], dtype=_np.float64)
                b = _np.asarray(mix.T if _np.ndim(mix) == 2 and _np.shape(mix)[0] == 2 else mix, dtype=_np.float64)
                n = min(_np.shape(a)[0], _np.shape(b)[0])
                a2 = a.reshape(n, -1)[:n] if _np.ndim(a) > 1 else a[:n].reshape(-1, 1)
                b2 = b.reshape(n, -1)[:n] if _np.ndim(b) > 1 else b[:n].reshape(-1, 1)
                num = float(_np.sum(a2 * b2)); den = float(_np.sqrt(_np.sum(a2 * a2) * _np.sum(b2 * b2)) + 1e-20)
                corr = num / den
                if corr > 0.999:
                    _log(log_cb, "· 提示：这是**单轨降噪模型**，输出与原始音频几乎相同（它只压稳态噪声、"
                                 "不分离人声/伴奏 —— 对音乐为主的素材这是正常结果）。要分离人声/伴奏请换用 "
                                 "Mel-Band Roformer（如 duality）等分离模型；要做强降噪可用「强降噪」功能。")
            except Exception:
                pass

        _log(log_cb, f"分离完成，共 {len(outputs)} 个音轨，耗时 {time.time() - start:.1f}s")
        return outputs
    finally:
        if restore:
            try:
                restore()
            except Exception:
                pass
        try:
            import transcribe_runtime as _TR
            # 分离模型的显存与内存同样要还（长音频分离一轮能吃满显存），
            # 并收缩 Windows 工作集（Python 不会把页还给系统）。
            _TR.release_memory(log_cb, "分离 ")
        except Exception:
            pass


#: 去噪模型候选（按优先级）。元组：(相对 models 目录的子路径, 文件名, 架构名)
#: 这些都在资源中心的「修复与工具 / VR」分类里，用户下完就能直接被「强降噪」用上。
_DENOISE_CANDIDATES = (
    ('vr/uvr_denoise', 'UVR-DeNoise.pth', 'UVR-VR'),
    ('vr/uvr_denoise_lite', 'UVR-DeNoise-Lite.pth', 'UVR-VR'),
    ('single/denoise_mel_band_roformer_aufr33_sdr_27_9959',
     'denoise_mel_band_roformer_aufr33_sdr_27.9959.ckpt', 'Mel-Band Roformer'),
    ('single/denoise_mel_band_roformer_aufr33_aggr_sdr_27_9768',
     'denoise_mel_band_roformer_aufr33_aggr_sdr_27.9768.ckpt', 'Mel-Band Roformer'),
)


def find_denoise_model():
    """找一个**已安装**的去噪模型，返回 (model_path, config_path, arch)；没有就返回 None。

    为什么要显式找：转录链路的「强降噪」档必须「要么真跑模型、要么明说不可用」——
    不允许出现「开关打开了但什么都没发生」（这正是「智能降噪」原来的毛病）。
    """
    root = os.environ.get('FUFUMIDI_MODELS_DIR') or ''
    if not root:
        return None
    for sub, fname, arch in _DENOISE_CANDIDATES:
        d = os.path.join(root, *sub.split('/'))
        mp = os.path.join(d, fname)
        try:
            if not os.path.isfile(mp) or os.path.getsize(mp) < 1024 * 1024:
                continue
        except Exception:
            continue
        cfg = None
        if arch != 'UVR-VR':       # roformer 必须有同名 yaml
            try:
                for f in sorted(os.listdir(d)):
                    if f.lower().endswith(('.yaml', '.yml')):
                        cfg = os.path.join(d, f)
                        break
            except Exception:
                cfg = None
            if not cfg:
                continue
        return mp, cfg, arch
    return None


def denoise_file(audio_path, log_cb=None, progress_cb=None):
    """用去噪模型处理整段音频，返回处理后文件路径；没有可用模型返回 None（由调用方说明）。"""
    found = find_denoise_model()
    if not found:
        return None
    mp, cfg, arch = found
    out_dir = tempfile.mkdtemp(prefix='fufumidi-denoise-')
    try:
        outs = separate(audio_path, out_dir, params={
            'model_path': mp, 'config_path': cfg, 'arch': arch,
            'output_format': 'wav', 'chunk_size': 926100, 'num_overlap': 4, 'batch_size': 2,
        }, log_cb=log_cb, progress_cb=progress_cb)
    except Exception as e:
        _log(log_cb, '· 去噪模型执行失败：%s' % e)
        return None
    if not outs:
        return None
    out = _pick_denoised(outs)
    if not out or not os.path.isfile(out):
        return None
    _log(log_cb, '· 去噪完成（%s → %s）' % (os.path.basename(mp), os.path.basename(out)))
    return out


def _pick_denoised(outs):
    """从去噪模型的输出里挑「干净的那条」。

    ★ 踩过的坑：VR 去噪模型（UVR-DeNoise 系列）一次输出**两条**：「Noise」和「No Noise」。
      取 outs[0] 正好拿到「噪声」那条 —— 实测把音频换成近乎静音的残差，
      转录结果直接变 0 个音符（电平还被归一顶到上限 +18dB）。
    规则：名字排除 noise 的那条优先，其次按 RMS 最大（干净信号占绝大部分能量）。
    """
    import numpy as np
    import soundfile as sf
    if len(outs) == 1:
        return outs[0]
    def score(p):
        name = os.path.basename(p).lower()
        if 'no noise' in name or 'nonoise' in name or 'no_noise' in name:
            return (0, 0.0)
        if 'denois' in name or 'clean' in name or 'dry' in name:
            return (1, 0.0)
        if 'noise' in name:
            return (3, 0.0)                     # 这是噪声本身，最后选
        return (2, 0.0)
    ranked = []
    for p in outs:
        try:
            d, _sr = sf.read(p, dtype='float32', always_2d=True)
            r = float(np.sqrt((d ** 2).mean()))
        except Exception:
            r = 0.0
        ranked.append((score(p)[0], -r, p))
    ranked.sort()
    return ranked[0][2]

def np_mean_channels(mix):
    import numpy as np
    mono = np.mean(mix, axis=0)
    return np.stack([mono, mono], axis=0)