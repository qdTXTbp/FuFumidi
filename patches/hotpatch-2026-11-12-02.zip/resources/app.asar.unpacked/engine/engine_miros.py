# -*- coding: utf-8 -*-
"""MIROS（AMT Challenge 2025 冠军）通用转录可选引擎
====================================================
MIROS = YourMT3+ 架构 + MusicFM 编码器。权重/运行时由资源中心下载，不随安装包分发。
目录：<FUFUMIDI_MODELS_DIR>/miros/
  site/      Python 依赖（含 transformers / lightning / MusicFM 所需）
  repo/      MIROS 源码 + logs/<exp>/<run>/checkpoints/last.ckpt
           + model/musicfm/data/pretrained_msd.pt

★ 2026-10-21 完善（此前只有 79 行薄封装）：
  1. `available()` 不再把训练批次目录名 `le2bzt53` 写死 —— 换一批训练
     「下载完了还说没装」，而这种不一致**不报错**，最难查；改成 glob 发现。
  2. 补 num_threads / 暂停闸门 / 显存归还（以前三个可选引擎里只有 YourMT3+ 有限线程）。
  3. `os.chdir(repo)` 改成 try/finally 保证还原（中途抛异常会把进程 cwd 留在 repo 里，
     后续队列的临时文件全落错地方）。
  4. 输出 0 音符时明确报错，不再静默产出空 MIDI（同 engine.py 的 0 音符保护）。
  5. 运行时公共能力统一走 transcribe_runtime.py。

推理入口仍是上游 repo 里的 `transcribe.transcribe(audio, midi)` ——
**不改上游逻辑**，只把外围（路径/线程/暂停/清理/校验）补齐。
"""
import os
import time

import transcribe_runtime as TR

_RUNTIME = "miros"


def find_runtime():
    """运行时目录（资源中心解包后）。"""
    return TR.find_runtime(_RUNTIME)


def find_checkpoint(rt=None):
    """定位 MIROS 微调权重（训练批次目录名会变，用 glob 发现）。

    布局是 `repo/logs/<exp>/<run>/checkpoints/last.ckpt`，但 <exp>/<run> 两层
    名字每次训练都不一样 —— 所以用 `**` 跨层匹配，**不写死任何一批的名字**
    （MIROS 接入第一版就写死过 `le2bzt53`，换批训练后「下载完了还说没装」）。
    """
    rt = rt or find_runtime()
    if not rt:
        return None
    return TR.glob_first(rt, os.path.join("**", "checkpoints", "last.ckpt"))


def find_musicfm(rt=None):
    """定位 MusicFM 预训练权重（`model/musicfm/data/pretrained_msd.pt`）。"""
    rt = rt or find_runtime()
    if not rt:
        return None
    return TR.glob_first(rt, os.path.join("**", "musicfm", "data", "*.pt"))


def available():
    """运行时就绪判据：目录 + 依赖 + 源码 + 两份权重，逐个用相对路径验。"""
    rt = find_runtime()
    if not rt:
        return False
    for rel in (os.path.join("site", "transformers", "__init__.py"),
                os.path.join("repo", "transcribe.py")):
        if not os.path.exists(os.path.join(rt, rel)):
            return False
    ckpt = find_checkpoint(rt)
    if not ckpt:
        return False
    try:
        if os.path.getsize(ckpt) < 100 * 1024 * 1024:   # 半截权重不算装好
            return False
    except OSError:
        return False
    return find_musicfm(rt) is not None


def _transcribe_miros_inner(audio_path, output_midi, params=None, log_cb=None, num_threads=None):
    rt = find_runtime()
    if not rt:
        raise RuntimeError(TR.runtime_missing_message(_RUNTIME))
    if not available():
        raise RuntimeError(
            "MIROS 运行时不完整（缺依赖 / 源码 / 权重）。请到「资源中心 → 转录模型」重新下载 MIROS。")
    threads = TR.limit_threads(num_threads)
    TR.install_pause(log_cb)
    TR.patch_torchaudio_soundfile()
    TR.stub_wandb()

    repo = os.path.join(rt, "repo")
    site = os.path.join(rt, "site")
    # ★ 2026-10-31（GitHub PR #37）：MIROS 自带的 site/torch 是 CPU 版，
    #   以前 prepare_paths 把它插在 sys.path[0]，正好盖住 PYTHONPATH 里 GPU 增强包
    #   的 cu128 torch —— 有显卡也报 GPU available: False，整首走 CPU。
    #   现在默认让增强包优先；要排障对照可设 FUFUMIDI_RUNTIME_BUNDLED_TORCH=1。
    bundled_torch = bool(os.environ.get("FUFUMIDI_RUNTIME_BUNDLED_TORCH"))
    TR.prepare_paths(rt, extra_dirs=[repo], keep_env_packages=not bundled_torch)
    # ★ 2026-11-12：MIROS 的 site 若是另一种 CPython 构建（实测 cp312 vs 运行时 3.11），
    #   prepare_paths 会拒绝挂载 —— 这里必须立刻给明确报错，不能带着半套依赖继续跑，
    #   否则后面会以「scipy 坏了 / numpy 找不到」的形式炸在毫无关系的地方。
    _skip = TR.last_site_skip()
    if _skip and os.path.normcase(_skip.get("site", "")) == os.path.normcase(site):
        raise RuntimeError(
            "MIROS 运行时是按 Python %s 构建的，当前引擎是 Python %s，无法加载。"
            "请到「资源中心 → 转录模型」重新下载匹配当前运行时的版本，或改用 MuScriptor / 其他模型。"
            % (_skip.get("abi"), _skip.get("python")))
    info = TR.torch_info()
    if log_cb:
        # 把真正加载的 torch / 设备 / 目录写进日志：慢的时候一眼能看出走的是 CPU 还是 GPU
        log_cb(TR.describe_torch(info, _RUNTIME))
        for msg in (TR.cpu_fallback_hint(_RUNTIME, info),
                    TR.torch_compat_warning(_RUNTIME, site)):
            if msg:
                log_cb(msg)
    # HF 端点与 wandb 由上游 import 链读取；离线包不该去连 HF
    os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
    os.environ["WANDB_MODE"] = "disabled"

    # ★ 2026-11-12：MIROS 的 MusicFM 编码器首次构建时要向 HuggingFace 拉
    #   `facebook/wav2vec2-conformer-rope-large-960h-ft` 的 config.json（约 2KB，
    #   运行时包不带它）。缓存命中时下面这句是纯本地操作；拉不到时
    #   huggingface_hub 会抛出难以理解的错误（实测两种：`LocalEntryNotFoundError`
    #   和 `expected string or bytes-like object, got 'NoneType'` —— 后者是它的
    #   内部代码拿 None 去做正则）。这里先主动拉一次，把失败翻译成人话。
    _MUSICFM_W2V_REPO = "facebook/wav2vec2-conformer-rope-large-960h-ft"
    try:
        from transformers import Wav2Vec2ConformerConfig as _W2VConf
        _W2VConf.from_pretrained(_MUSICFM_W2V_REPO)
    except Exception as e:  # noqa: BLE001
        raise RuntimeError(
            "MIROS 首次运行需要联网获取 MusicFM 编码器配置（%s/config.json，约 2KB，"
            "已按 hf-mirror.com 镜像重试）。当前网络不可达：%s。"
            "配置只需成功下载一次，之后可离线使用；也可以改用 MuScriptor / Basic Pitch 转录。"
            % (_MUSICFM_W2V_REPO, str(e)[:200]))

    if log_cb:
        log_cb("MIROS：加载 MusicFM + MIROS checkpoint（首次较慢，%s）"
               % ("线程 %d" % threads if threads else "CPU"))
    t_all = time.perf_counter()
    cwd = os.getcwd()
    os.chdir(repo)                      # 上游用相对路径读 config，必须切过去
    try:
        import transcribe as miros_transcribe
        try:
            miros_transcribe.transcribe(audio_path, output_midi)
        except RuntimeError as e:
            # ★ 整首歌的中间激活随歌长增长（pre_decoder 对全长序列做逐层变换），
            #   长歌曲 + 系统内存紧张（浏览器 / 游戏同时开着）时容易 OOM：
            #   `DefaultCPUAllocator: not enough memory`。把它翻译成人话。
            if "not enough memory" in str(e) or "DefaultCPUAllocator" in str(e):
                raise RuntimeError(
                    "MIROS 内存不足：整首歌的中间激活随歌长增长，CPU 推理长歌曲很吃内存。"
                    "请关闭占内存的程序（游戏 / 浏览器）后重试；整首歌建议改用 MuScriptor —— "
                    "它更快、内存占用小得多。") from e
            raise
    finally:
        os.chdir(cwd)                   # ★ 一定要还原：否则后续队列的临时文件全落错地方
        TR.release_gpu()
        TR.log_timing(log_cb, "MIROS 总计", t_all)

    n = TR.count_notes(output_midi)
    if n == 0:
        raise RuntimeError(
            "MIROS 未输出任何音符（音频近乎静音 / 只有噪声 / 权重与素材不匹配）。"
            "可换 MuScriptor 或 Basic Pitch 再试。")
    if log_cb:
        log_cb("MIROS：输出 %d 个音符 → %s" % (n, os.path.basename(output_midi)))
    return n


def transcribe_miros(audio_path, output_midi, params=None, log_cb=None, num_threads=None):
    """对外入口：跑完把本次插进 sys.path 的运行时目录清掉。

    常驻引擎复用同一个进程；MIROS 的 site 里带着另一套 numpy/torch，
    留在 sys.path 会污染后续 MuScriptor 任务（症状是「scipy 坏了」）。
    """
    try:
        return _transcribe_miros_inner(audio_path, output_midi, params=params,
                                       log_cb=log_cb, num_threads=num_threads)
    finally:
        TR.restore_paths()


import time  # noqa: E402  （放在文件末尾只为让上面的 import 分组保持可读）
