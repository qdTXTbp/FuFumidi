#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
音乐转 MIDI 工具 v2.0
======================
任意歌曲 / 人声 / 乐器 → MIDI 转录工具
- 通用识别：任意歌曲、人声、多乐器（basic-pitch）
- 钢琴专用：纯钢琴高精度 + 踏板（piano-transcription）
- 人声分离：demucs 分声部转录（可选增强）
- 原生支持所有音频/视频格式；内置 MIDI 播放器；参数预设

三种用法:
    1) 图形界面 (推荐):    python music2midi.py
    2) 单文件转换:         python music2midi.py convert 歌曲.mp3 [options]
    3) 批量转换:           python music2midi.py batch [-i input] [-o output]

跨平台说明:
    主程序文件名为 ASCII（music2midi.py），配合 ASCII 编码的 .bat 启动器，
    在任何语言版本的 Windows / macOS / Linux 上都不会出现乱码。
"""

import argparse
import json
import os
import sys
import warnings

VERSION = "3.2.2"

def _patch_tqdm_compat():
    """兼容新版 tqdm 缺少 set_lock/get_lock 导致 huggingface_hub 导入失败的问题。"""
    try:
        from tqdm.auto import tqdm as _tqdm_cls
        import threading
        if not hasattr(_tqdm_cls, "set_lock"):
            _tqdm_cls.set_lock = lambda lock: None
        if not hasattr(_tqdm_cls, "get_lock"):
            _tqdm_cls.get_lock = lambda: threading.RLock()
    except Exception:
        pass

_patch_tqdm_compat()



def _setup_utf8_console():
    """跨平台防乱码：让控制台输出统一使用 UTF-8。

    - 把 Python 的 stdout/stderr 重配置为 UTF-8（含重定向到文件/管道时）
    - Windows 下同时把控制台代码页切到 UTF-8（65001），使中文能正确显示
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.kernel32.SetConsoleOutputCP(65001)
            ctypes.windll.kernel32.SetConsoleCP(65001)
        except Exception:
            pass


# 屏蔽第三方噪音警告
warnings.filterwarnings("ignore")
try:
    import logging
    logging.getLogger().setLevel(logging.ERROR)
except Exception:
    pass

_setup_utf8_console()


def _get_base_dir():
    if getattr(sys, "frozen", False):  # PyInstaller 冻结环境
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


BASE_DIR = _get_base_dir()
DEFAULT_INPUT_DIR = os.path.join(BASE_DIR, "input")
DEFAULT_OUTPUT_DIR = os.path.join(BASE_DIR, "output")


def dependencies_ok(mode=None):
    """检查指定模式（默认任意一种）的核心依赖是否可用。"""
    from engine import engine_available, MODES
    if mode:
        return engine_available(mode)
    return any(engine_available(m) for m in MODES)


def print_deps_help(mode=None):
    from engine import MODES
    print("=" * 60)
    print("  检测到缺少必要的 Python 依赖，无法进行转录。")
    print("")
    print("  请先双击运行本目录下的  install.bat 一键安装")
    print("  或手动执行:  pip install -r requirements.txt")
    if mode:
        print(f"")
        print(f"  当前模式「{MODES.get(mode, ('', ''))[0]}」还需要：")
        if mode == "separate":
            print("     pip install pymss")
        else:
            print("     （install.bat 已包含）")
    print("=" * 60)


# ---------------------------------------------------------------------------
# 命令行转换
# ---------------------------------------------------------------------------
def _resolve_params(args, mode):
    """把命令行参数 / 预设合并成该模式的参数字典。"""
    import presets
    from engine import DEFAULTS

    p = dict(DEFAULTS.get(mode, {}))
    if args.preset:
        presets_all, _ = presets.load_presets()
        pr = presets_all.get(args.preset)
        if pr:
            p.update(pr.get("params", {}))
            if pr.get("mode"):
                mode = pr["mode"]
        else:
            print(f"[警告] 找不到预设「{args.preset}」，使用默认参数")

    if mode == "universal":
        if args.onset_threshold is not None: p["onset_threshold"] = args.onset_threshold
        if args.frame_threshold is not None: p["frame_threshold"] = args.frame_threshold
        if args.min_note_length is not None: p["minimum_note_length"] = args.min_note_length
        if args.minimum_frequency is not None: p["minimum_frequency"] = args.minimum_frequency or None
        if args.maximum_frequency is not None: p["maximum_frequency"] = args.maximum_frequency or None
        if args.no_melodia: p["melodia_trick"] = False
        if getattr(args, "multiple_pitch_bends", False): p["multiple_pitch_bends"] = True
        if args.tempo is not None: p["midi_tempo"] = args.tempo
    elif mode == "piano":
        if args.onset_threshold is not None: p["onset_threshold"] = args.onset_threshold
        if args.frame_threshold is not None: p["frame_threshold"] = args.frame_threshold
        if args.min_note_ms is not None: p["min_note_ms"] = args.min_note_ms
        if args.merge_gap_ms is not None: p["merge_gap_ms"] = args.merge_gap_ms
        if args.no_pedal: p["include_pedal"] = False
    elif mode == "separate":
        if args.onset_threshold is not None: p["onset_threshold"] = args.onset_threshold
        if args.frame_threshold is not None: p["frame_threshold"] = args.frame_threshold
        if args.min_note_length is not None: p["minimum_note_length"] = args.min_note_length
        if args.with_drums: p["include_drums"] = True
        if args.export_stems: p["export_stems"] = True
        if args.stem_format: p["stem_format"] = args.stem_format
        if args.tempo is not None: p["midi_tempo"] = args.tempo
    # 智能预处理 / 后处理开关（各模式通用，Electron 端传入）
    if getattr(args, "denoise", False): p["denoise"] = True
    # 降噪档位（off/light/strong）——只在 worker 的 Namespace 里加是不够的，必须在这里进 params
    # （2026-10-15：这张"三跳"表漏一个键，界面设了也到不了引擎；见 scripts/audit-param-contract.cjs）
    if getattr(args, "denoise_mode", None): p["denoise_mode"] = str(args.denoise_mode)
    if getattr(args, "normalize", False): p["normalize"] = True
    if getattr(args, "auto_bpm", False): p["auto_bpm"] = True
    # 识别片段长度（所有转录模型共用）：**默认不开启**（用户 2026-10-23）。
    # 0/空/不传 = 各模型原生块长，与"没有这个选项"时行为一致；>0 才进 params。
    _sg = getattr(args, "segment_sec", None)
    if _sg is not None:
        try:
            if float(_sg) > 0:
                p["segment_sec"] = float(_sg)
        except (TypeError, ValueError):
            pass
    # 显存策略（auto / low / allow）：由主进程传，引擎按模型降批或保持
    _mm = getattr(args, "memory_mode", None)
    if _mm in ("auto", "low", "allow"):
        p["memory_mode"] = str(_mm)
    # ★★ 2026-11-07：以下 muscriptor 专属参数里，除**官方 instruments 硬约束**外，
    #   其余（标签模型 / 探测段长 / 批量推理 / 生成参数 / 延长上限 / 音色稳定 / 节拍开关）
    #   引擎侧已全部不再读取 —— MuScriptor 走官方默认调用（见 engine_muscriptor）。
    #   保留解析只为兼容旧队列 / 旧预设文件：老配置照样能载入，只是这些键不改变结果。
    # ★ 2026-11-08：`muscriptor_instruments` 重新生效 —— 它是官方 transcribe() 的
    #   instruments= 硬约束（第三方包装 CLI 的 --instrument），默认空选仍是官方自动识别。
    #   ★ no_merge / no_velnorm 与 muscriptor 无关，照旧生效（见下两行）。
    if getattr(args, "no_merge", False): p["merge_overlap"] = False
    if getattr(args, "no_velnorm", False): p["normalize_vel"] = False
    # 子模型选择：universal → basic / muscriptor；piano → piano_pt / aria / transkun
    if getattr(args, "model", None): p["model"] = args.model
    if getattr(args, "model_size", None): p["model_size"] = args.model_size
    # muscriptor 批量推理（0=关闭边界质量优先；>=2 开启批量吞吐）
    _mb = getattr(args, "muscriptor_batch", None)
    if _mb: p["muscriptor_batch"] = int(_mb)
    # 节拍网格检测（仅 muscriptor 用到）：勾选才加载 Beat This! 权重，
    # 未下载/加载失败时由 engine_muscriptor 自行跳过。必须在这里显式取出——
    # 只放在 worker 的 Namespace 里也不够，参数最终要靠这里进 params。
    if getattr(args, "beat_grid", False): p["beat_grid"] = True
    # 旋律乐器组（仅 muscriptor 用到）：auto=出结果后智能识别并归并；
    # 逗号分隔的组名=直接作为硬约束交给模型；不传=不干预。
    _mi = getattr(args, "muscriptor_instruments", None)
    if _mi: p["muscriptor_instruments"] = str(_mi)
    # 官方解码档位（2026-11-10）：greedy = 官方 Quickstart 默认，不加任何 kwargs；
    # sample = 官方 use_sampling=True + temperature=0.9，实测能补上逐块漏掉的鼓点。
    # 只认这两个白名单值，别的值一律当默认处理，避免旧配置把怪值带进上游。
    _md = getattr(args, "muscriptor_decode", None)
    if _md in ("greedy", "sample"): p["muscriptor_decode"] = str(_md)
    # 音频标签模型 / 自动探测（分段）：CLI 与 worker 两条路径都必须进 params，
    # 否则界面选的 CED-Small 会被引擎当成默认 AudioSet。
    _at = getattr(args, "audio_tagger", None)
    if _at: p["audio_tagger"] = str(_at)
    _pss = getattr(args, "probe_segment_sec", None)
    if _pss is not None: p["probe_segment_sec"] = float(_pss)
    _atw = getattr(args, "audio_tagger_window_sec", None)
    if _atw is not None: p["audio_tagger_window_sec"] = float(_atw)
    if getattr(args, "audio_tagger_whole_song", False): p["audio_tagger_whole_song"] = True
    # 超长音符上限（仅 muscriptor 用到）：默认 15 秒由引擎侧兜底；
    # 这里显式取出，命令行与 worker 两条路径才都能覆盖它。
    _mh = getattr(args, "max_note_hold", None)
    if _mh is not None: p["max_note_hold"] = float(_mh)
    # ① 回放台（仅 muscriptor 用到，开发/诊断用，界面不暴露）：
    #   --dump-tokens   真实转录时把 token 流顺手落盘（JSONL，几 MB）
    #   --replay-tokens 从落盘流重跑解码器（不加载模型、不用 GPU）
    # 为什么需要：僵尸音符那类缺陷出在解码器（tokenizer/notes.py 的 OpenNoteTracker），
    # 修一次却要重跑 100 分钟音频（实测约 48 分钟）；走回放只要约 1 分钟。
    _dt = getattr(args, "dump_tokens", None)
    if _dt: p["dump_tokens"] = str(_dt)
    _rt = getattr(args, "replay_tokens", None)
    if _rt: p["replay_tokens"] = str(_rt)
    # ② 计算精度（仅 muscriptor 用到）：不传 = 上游默认 fp32。
    # bf16 在本机（Zen 5 / AVX512-BF16）实测提速 43% 且事件数一致，
    # 但它改数值精度、属影响质量的开关，所以由用户显式选。
    _dt = getattr(args, "precision", None)
    if _dt and str(_dt).lower() not in ("fp32", "float32", "auto"):
        p["dtype"] = str(_dt).lower()
    # ④ 批 B：MuScriptor 生成参数（默认不传 = 旧版行为）。
    for _k in ("temperature", "cfg_coef", "beam_size"):
        _v = getattr(args, _k, None)
        if _v is not None: p[_k] = _v
    _pf = getattr(args, "prelude_forcing", None)
    if _pf is not None: p["prelude_forcing"] = bool(_pf)
    return p, mode


def cmd_convert(args):
    from engine import transcribe

    src = os.path.abspath(args.input)
    if not os.path.isfile(src):
        print(f"[错误] 找不到文件: {src}")
        return 1

    params, mode = _resolve_params(args, args.engine_mode)
    out = args.output
    if not out:
        out = os.path.splitext(src)[0] + ".mid"
    out = os.path.abspath(out)

    print(f"[1/2] 正在转录（{mode}）: {os.path.basename(src)}")
    try:
        out_dir = os.path.dirname(out)
        if out_dir:
            os.makedirs(out_dir, exist_ok=True)

        def log(msg):
            print(f"      {msg}")

        note_count = transcribe(src, out, mode=mode, params=params, log_cb=log,
                                perf_mode=args.perf)
        # ★ WP2-2（2026-10-14）：这里原先读 `engine_separate.last_stem_exports` 给
        #   `stems` 赋值，但那段**不可达** —— `mode == "separate"` 在 engine.py 的
        #   分发里直接 raise（音频分离已改走 `separate` 子命令 → engine_msst），
        #   所以 `transcribe()` 先抛错，后面的代码永远执行不到。
        #   随之 `engine/engine_separate.py`（demucs 版分离）成为纯死代码，已删除。
        stems = []
    except Exception as e:
        print(f"[错误] 转录失败: {e}")
        return 1

    print(f"[2/2] 完成！识别出 {note_count} 个音符")
    print(f"      输出: {out}")
    res = {'ok': True, 'note_count': note_count, 'out': out}
    if stems:
        res['stems'] = stems
        for s in stems:
            print(f"      分轨: {s}")
    print(f"###RESULT {json.dumps(res, ensure_ascii=False)}")
    return 0


def _collect_audio_files(input_dir):
    from audio_io import AUDIO_EXTENSIONS
    found = []
    for root, _dirs, names in os.walk(input_dir):
        for name in sorted(names):
            if os.path.splitext(name)[1].lower() in AUDIO_EXTENSIONS:
                found.append(os.path.join(root, name))
    return sorted(found)


def cmd_batch(args):
    from engine import transcribe

    input_dir = os.path.abspath(args.input_dir)
    output_dir = os.path.abspath(args.output_dir)
    os.makedirs(input_dir, exist_ok=True)
    os.makedirs(output_dir, exist_ok=True)

    files = _collect_audio_files(input_dir)
    if not files:
        print(f"[提示] 在 {input_dir} 中没有找到音频文件。")
        print("       请把 WAV / MP3 / FLAC / 视频等文件放进去后再运行一次。")
        return 1

    params, mode = _resolve_params(args, args.engine_mode)
    print(f"共找到 {len(files)} 个音频文件，开始转换（模式: {mode}）...")
    print("=" * 60)

    ok = 0
    for i, f in enumerate(files, 1):
        rel = os.path.relpath(f, input_dir)
        out_mid = os.path.join(output_dir, os.path.splitext(rel)[0] + ".mid")
        os.makedirs(os.path.dirname(out_mid), exist_ok=True)
        try:
            note_count = transcribe(f, out_mid, mode=mode, params=params,
                                    perf_mode=args.perf)
            ok += 1
            print(f"[{i}/{len(files)}] OK   {rel}  →  {note_count} 音符")
        except Exception as e:
            print(f"[{i}/{len(files)}] 失败 {rel}  →  {e}")

    print("=" * 60)
    print(f"转换完成: 成功 {ok} / {len(files)}")
    print(f"输出目录: {output_dir}")
    return 0 if ok == len(files) else 1


def cmd_separate(args):
    """音频处理（MSST 分离）：把单个音频分离为所选音轨，写入输出目录。"""
    import engine_msst

    src = os.path.abspath(args.input)
    if not os.path.isfile(src):
        print(f"[错误] 找不到文件: {src}")
        return 1

    out_dir = os.path.abspath(args.output or os.path.join(os.path.dirname(src), "separated"))
    os.makedirs(out_dir, exist_ok=True)

    params = {
        "model_path": getattr(args, "model", None),
        "config_path": getattr(args, "config", None),
        "arch": getattr(args, "arch", None),
        "chunk_size": args.chunk_size,
        "num_overlap": args.num_overlap,
        "batch_size": args.batch_size,
        "normalize": bool(getattr(args, "normalize", False)),
        "use_tta": bool(getattr(args, "tta", False)),
        "stems": [s.strip() for s in args.stems.split(",") if s.strip()] if getattr(args, "stems", None) else None,
        "output_format": (getattr(args, "format", None) or "wav").lower().lstrip("."),
    }

    print(f"[1/2] 正在分离（MSST）: {os.path.basename(src)}")
    try:
        def log(msg):
            print(f"      {msg}")

        def prog(p):
            sys.stdout.write(f"###PROG {json.dumps({'percent': round(p, 1)})}\n")
            sys.stdout.flush()

        outputs = engine_msst.separate(src, out_dir, params, log_cb=log, progress_cb=prog)
    except Exception as e:
        print(f"[错误] 分离失败: {e}")
        res = {'ok': False, 'error': str(e)}
        print(f"###RESULT {json.dumps(res, ensure_ascii=False)}")
        return 1

    print(f"[2/2] 完成！共 {len(outputs)} 个音轨")
    res = {'ok': True, 'outputs': outputs, 'out_dir': out_dir}
    print(f"###RESULT {json.dumps(res, ensure_ascii=False)}")
    return 0


def cmd_probe():
    """环境诊断：输出一行 JSON（Electron 端解析）。"""
    from engine import MODES, engine_available
    out = {"ok": True, "app": "FuFumidi 转录引擎", "version": VERSION,
           "python": sys.version.split()[0], "engines": {}, "libs": {}}
    for m in MODES:
        try:
            out["engines"][m] = {"available": bool(engine_available(m))}
        except Exception as e:
            out["engines"][m] = {"available": False, "error": str(e)}
    for lib in ("numpy", "librosa", "soundfile", "pretty_midi", "scipy",
                "onnxruntime", "torch", "basic_pitch", "demucs"):
        try:
            mod = __import__(lib)
            out["libs"][lib] = getattr(mod, "__version__", "ok")
        except Exception:
            out["libs"][lib] = None
    # GPU 加速检测（CUDA / MPS / DirectML / ONNX GPU）
    try:
        from engine_gpu import detect as gpu_detect
        out["gpu"] = gpu_detect()
    except Exception as e:
        out["gpu"] = {"available": False, "error": str(e)}
    # 性能档位自动评估（UI 据此推荐/解锁/锁定性能选项）
    try:
        from engine_perf import detect_recommended
        out["perf"] = detect_recommended()
    except Exception as e:
        out["perf"] = {"recommended": "quality", "max_tier": "quality", "error": str(e)}
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


# ---------------------------------------------------------------------------
# 图形界面
# ---------------------------------------------------------------------------
def run_gui():
    from engine import transcribe, engine_available, MODES
    import gui

    # 至少需要一种引擎
    ok_modes = [m for m in MODES if engine_available(m)]
    if not ok_modes:
        from PySide6.QtWidgets import QApplication, QMessageBox
        app = QApplication([])
        QMessageBox.critical(None, "缺少依赖",
            "检测到缺少必要的转录引擎（basic-pitch / piano-transcription）。\n\n"
            "请先双击运行 install.bat 一键安装。")
        return 1
    return gui.run_gui(transcribe, DEFAULT_OUTPUT_DIR, VERSION)


# ---------------------------------------------------------------------------
# 参数
# ---------------------------------------------------------------------------
def build_parser():
    from engine import MODES
    parser = argparse.ArgumentParser(
        prog="music2midi",
        description="任意歌曲/人声/乐器 → MIDI 转录工具（通用识别 / 钢琴专用 / 人声分离）",
        epilog="示例:\n"
               "  python music2midi.py                          # 打开图形界面\n"
               "  python music2midi.py convert 歌曲.mp3         # 单文件转换\n"
               "  python music2midi.py convert 歌曲.mp3 --mode piano\n"
               "  python music2midi.py batch                    # 批量转换 input/ 文件夹",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("mode", nargs="?", choices=["convert", "batch", "probe", "gui", "worker", "separate"],
                        default="gui", help="运行模式（默认 gui）")
    parser.add_argument("input", nargs="?", help="[convert] 输入音频文件")
    parser.add_argument("-o", "--output", help="[convert] 输出 MIDI 路径（默认与输入同名同目录）")
    parser.add_argument("-i", "--input-dir", default=DEFAULT_INPUT_DIR,
                        help="[batch] 输入文件夹（默认 input/）")
    parser.add_argument("--output-dir", default=DEFAULT_OUTPUT_DIR,
                        help="[batch] 输出文件夹（默认 output/）")

    parser.add_argument("--mode", "--engine", dest="engine_mode", default="universal",
                        choices=list(MODES.keys()),
                        help="转录模式: universal=通用(默认) / piano=钢琴 / separate=人声分离")
    parser.add_argument("--preset", default=None, help="载入参数预设（名称见界面或 presets.json）")
    parser.add_argument("--perf", default="quality",
                        choices=["quality", "balanced", "fast"],
                        help="性能模式: quality=最高质量(默认,全部核心) / "
                             "balanced=均衡 / fast=高性能(低配省内存)")
    parser.add_argument("--model", default=None,
                        help="子模型: universal→basic/muscriptor；piano→piano_pt/aria/transkun")
    parser.add_argument("--model-size", default=None,
                        help="MuScriptor 规格: small / medium / large")

    g = parser.add_argument_group("转录参数（通用/钢琴/分离共用）")
    g.add_argument("--onset-threshold", type=float, default=None,
                   help="起音阈值 0~1，越小越灵敏")
    g.add_argument("--frame-threshold", type=float, default=None,
                   help="音符判定阈值 0~1，越大越干净")
    g.add_argument("--denoise", action="store_true", help="智能预处理·谱减法降噪")
    g.add_argument("--denoise-mode", choices=["off", "light", "strong"], default=None,
                   help="降噪档位：off=关 / light=改进谱减法 / strong=去噪模型（见 engine/audio_chain.py）")
    g.add_argument("--normalize", action="store_true", help="智能预处理·响度平衡")
    g.add_argument("--auto-bpm", action="store_true", help="自动检测 BPM 作为导出速度")
    g.add_argument("--no-merge", action="store_true", help="关闭重叠音符合并")
    g.add_argument("--no-velnorm", action="store_true", help="关闭力度归一化")

    g = parser.add_argument_group("通用/分离（basic-pitch）参数")
    g.add_argument("--segment-sec", dest="segment_sec", type=float, default=None,
                   help="识别片段长度（秒，所有转录模型）：0/不传 = 各模型原生块长（默认，不开启）")
    g.add_argument("--memory-mode", dest="memory_mode", choices=["auto", "low", "allow"], default=None,
                   help="显存策略：low=低显存自动降批（推荐）/ allow=允许驱动借用系统内存 / auto=默认")
    g.add_argument("--timbre-stabilize", action="store_true",
                   help="MuScriptor 音色稳定后处理：把短命孤立乐器轨并入邻近主导轨（默认关；界面预设默认开）")
    g.add_argument("--min-note-length", type=float, default=None,
                   help="最短音符时长(ms)（默认 128）")
    g.add_argument("--min-freq", "--minimum-frequency", dest="minimum_frequency",
                   type=float, default=None, help="最低音高(Hz)，0=不限")
    g.add_argument("--max-freq", "--maximum-frequency", dest="maximum_frequency",
                   type=float, default=None, help="最高音高(Hz)，0=不限")
    g.add_argument("--no-melodia", action="store_true", help="关闭旋律增强")
    g.add_argument("--multiple-pitch-bends", dest="multiple_pitch_bends", action="store_true",
                   help="[basic] 允许同一音符挂多条弯音曲线")
    g.add_argument("--beat-grid", action="store_true",
                   help="[muscriptor] 加载 Beat This! 权重做节拍网格检测（未下载/失败时自动跳过）")
    g.add_argument("--audio-tagger-window-sec", dest="audio_tagger_window_sec", type=float, default=None,
                   help="[muscriptor] 音频标签探测窗口长度（秒）")
    g.add_argument("--audio-tagger-whole-song", dest="audio_tagger_whole_song", action="store_true",
                   help="[muscriptor] 音频标签探测使用整首（全曲均匀采样）")
    g.add_argument("--audio-tagger", dest="audio_tagger", default=None,
                   help="[muscriptor] 音频标签模型：audioset（默认）或 ced")
    g.add_argument("--probe-segment-sec", dest="probe_segment_sec", type=float, default=None,
                   help="[muscriptor] 自动探测（分段）的段长（秒）")
    g.add_argument("--muscriptor-instruments", dest="muscriptor_instruments", default=None,
                   help="[muscriptor] 乐器组硬约束：逗号分隔的组名（voice / acoustic_piano /"
                        " clean_electric_guitar / synth_lead / flutes / organ / drums …，"
                        "见 muscriptor list-instruments）。不传=不限定，模型自由判定")
    g.add_argument("--muscriptor-decode", dest="muscriptor_decode", default=None,
                   choices=("greedy", "sample"),
                   help="[muscriptor] 官方解码档位：greedy=官方默认贪心（可复现）；"
                        "sample=use_sampling + temperature=0.9（补逐块漏鼓，结果有随机性）")
    # ① 回放台（诊断/开发用，界面不暴露）——见 engine_muscriptor.py 顶部说明
    g.add_argument("--temperature", type=float, default=None,
                   help="[muscriptor] 采样温度（默认 1.0=贪婪解码；设了即自动开启采样）")
    g.add_argument("--cfg-coef", dest="cfg_coef", type=float, default=None,
                   help="[muscriptor] 无分类器引导系数（默认 1.0；设了即自动开启采样）")
    g.add_argument("--beam-size", dest="beam_size", type=int, default=None,
                   help="[muscriptor] 束搜索宽度（默认 1=关闭；越大越慢）")
    g.add_argument("--no-prelude-forcing", dest="prelude_forcing", action="store_false", default=None,
                   help="[muscriptor] 关闭跨块延音缝合（分块边界上的延音不再缝回长音；"
                        "默认开＝解码关掉模型强制 tie，再按同音高同音色缝合，从根上杜绝僵尸长音）")
    g.add_argument("--precision", dest="precision", default=None,
                   choices=["fp32", "bf16", "fp16"],
                   help="[muscriptor] 计算精度（默认 fp32）。bf16 更快但数值精度不同")
    g.add_argument("--dump-tokens", dest="dump_tokens", default=None, metavar="FILE",
                   help="[诊断] 把 MuScriptor token 流落盘（JSONL）")
    g.add_argument("--replay-tokens", dest="replay_tokens", default=None, metavar="FILE",
                   help="[诊断] 从落盘的 token 流重跑解码器（不加载模型/不用 GPU，约 1 分钟）")
    g.add_argument("--max-note-hold", dest="max_note_hold", type=float, default=None,
                   help="[muscriptor] 超长音符上限（秒，默认 0=不截断）：超过就强制收尾（硬保险，会误伤真实长音；"
                        "治长音频转录的僵尸音符（实测 100 分钟录播里出现 4320 秒的音）")
    g.add_argument("--tempo", type=int, default=None, help="MIDI 速度 BPM（默认 120）")
    g.add_argument("--with-drums", action="store_true",
                   help="[separate] 同时输出鼓组节奏轨")
    g.add_argument("--stem-format", type=str, default=None, help="分轨导出格式 wav/flac/m4a")
    g.add_argument("--export-stems", action="store_true",
                   help="[separate] 导出分离后的音频分轨 WAV（vocals/bass/other/drums）")

    g = parser.add_argument_group("钢琴（piano-transcription）参数")
    g.add_argument("--min-note-ms", type=int, default=None, help="最小音符时长(ms)")
    g.add_argument("--merge-gap-ms", type=int, default=None, help="同音高音符合并间隔(ms)")
    g.add_argument("--no-pedal", action="store_true", help="不输出踏板事件")

    g = parser.add_argument_group("音频处理（MSST 分离）参数")
    g.add_argument("--arch", type=str, default=None, help="模型架构名（BN-Roformer/Mel-Band Roformer/HTDemucs/...）")
    g.add_argument("--config", type=str, default=None, help="MSST 模型 .yaml 配置路径")
    g.add_argument("--chunk-size", type=int, default=None, help="分块大小（样本数，建议 44100 整数倍）")
    g.add_argument("--num-overlap", type=int, default=None, help="重叠数 N（默认 4，增大提高效果/耗时）")
    g.add_argument("--batch-size", type=int, default=None, help="批次大小（减小降低显存）")
    g.add_argument("--tta", action="store_true", help="启用 TTA（推理时间 ×3，质量略升）")
    g.add_argument("--stems", type=str, default=None, help="输出音轨，逗号分隔（默认全部）")
    g.add_argument("--format", type=str, default=None, help="输出格式：wav/flac/mp3（默认 wav）")

    parser.add_argument("--version", action="version", version=f"音乐转MIDI工具 {VERSION}")
    return parser


def cmd_worker():
    """常驻 worker：从 stdin 读 JSON 请求，逐条执行 convert，保持模型/会话常驻。"""
    import argparse as _ap
    import contextlib
    import io
    import json as _json
    import sys as _sys

    _patch_tqdm_compat()
    for line in _sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = _json.loads(line)
            job = req.get('_id')
            ns = _ap.Namespace(
                input=req.get('audio'),
                output=req.get('out'),
                engine_mode=req.get('mode', 'universal'),
                perf=req.get('perf', 'quality'),
                preset=req.get('preset'),
                onset_threshold=req.get('onset_threshold'),
                frame_threshold=req.get('frame_threshold'),
                min_note_length=req.get('min_note_length'),
                min_note_ms=req.get('min_note_ms'),
                merge_gap_ms=req.get('merge_gap_ms'),
                denoise=bool(req.get('denoise')),
        denoise_mode=req.get('denoise_mode'),
                normalize=bool(req.get('normalize')),
                auto_bpm=bool(req.get('auto_bpm')),
                no_merge=bool(req.get('no_merge')),
                no_velnorm=bool(req.get('no_velnorm')),
                with_drums=bool(req.get('with_drums')),
                stem_format=req.get('stem_format'),
                export_stems=bool(req.get('export_stems')),
                no_pedal=bool(req.get('no_pedal')),
                minimum_frequency=req.get('min_freq'),
                maximum_frequency=req.get('max_freq'),
                no_melodia=bool(req.get('no_melodia')),
                # 多条弯音（basic-pitch 唯一没转发的用户可见参数）：漏了这一项时
                # 界面勾了也到不了引擎，basic-pitch 会一直按默认 False 跑。
                multiple_pitch_bends=bool(req.get('multiple_pitch_bends')),
                tempo=req.get('tempo'),
                model=req.get('model'),
                model_size=req.get('model_size'),
                muscriptor_batch=req.get('muscriptor_batch'),
                # 旋律乐器组：漏掉这一项时界面选了「人声」也传不进引擎，
                # 模型仍会自由改判乐器（甩葱歌那类「同一旋律换音色」的根因）。
                muscriptor_instruments=req.get('muscriptor_instruments'),
                # 官方解码档位：serve 常驻会话路径同样要带，漏了界面选的采样档会静默失效
                muscriptor_decode=req.get('muscriptor_decode'),
                probe_segment_sec=req.get('probe_segment_sec'),
                audio_tagger=req.get('audio_tagger'),
                audio_tagger_window_sec=req.get('audio_tagger_window_sec'),
                audio_tagger_whole_song=bool(req.get('audio_tagger_whole_song')),
                # 节拍网格检测开关：漏了这一项时模板/界面勾了也传不进引擎，
                # 引擎会一直按默认关闭处理（日志固定输出「已关闭节拍网格检测」）。
                beat_grid=bool(req.get('beat_grid')),
                # 超长音符上限：漏了这一项时主进程设了也到不了引擎（同上面两条的坑），
                # 引擎会一直用默认 15s。
                max_note_hold=req.get('max_note_hold'),
                # ⑤ 静音分段（漏一项界面勾了也到不了引擎）
                # 识别片段长度：漏这一项时界面滑条调了也到不了引擎
                segment_sec=req.get('segment_sec'),
                memory_mode=req.get('memory_mode'),
                timbre_stabilize=bool(req.get('timbre_stabilize')),
                # ④ 批 B：MuScriptor 生成参数（漏一项界面调了也不生效 —— 同上面几条的坑）
                temperature=req.get('temperature'),
                cfg_coef=req.get('cfg_coef'),
                beam_size=req.get('beam_size'),
                prelude_forcing=req.get('prelude_forcing'),
                precision=req.get('precision'),
            )
            class _LogTee(io.StringIO):
                """stdout 分流：把转换日志逐行实时转发到真实 stdout（###LOG 协议），
                worker 模式的 UI 因此能看到引擎日志与 [计时] 各阶段耗时；
                ###RESULT 行不转发（由 buf 常规提取）。"""

                def __init__(self, job_id, real):
                    super().__init__()
                    self._job = job_id
                    self._real = real

                def write(self, s):
                    try:
                        for line in s.splitlines():
                            line = line.rstrip()
                            if line and not line.startswith('###RESULT'):
                                self._real.write('###LOG ' + _json.dumps({'_id': self._job, 'line': line}, ensure_ascii=False) + '\n')
                                self._real.flush()
                    except Exception:
                        pass
                    return super().write(s)

            _real_stdout = _sys.stdout
            buf = _LogTee(job, _real_stdout)
            code = 1
            res = None
            try:
                with contextlib.redirect_stdout(buf):
                    code = cmd_convert(ns)
            except Exception as e:
                buf.write('\n[worker] convert error: ' + str(e))
            out = buf.getvalue()
            for l in out.splitlines():
                if l.startswith('###RESULT '):
                    try:
                        res = _json.loads(l[len('###RESULT '):])
                    except Exception:
                        res = None
                    break
            if res is None:
                res = {'ok': code == 0, 'error': out[-600:]}
            if job is not None:
                res['_id'] = job
            _sys.stdout.write('###RESULT ' + _json.dumps(res, ensure_ascii=False) + '\n')
            _sys.stdout.flush()
        except Exception as e:
            _sys.stdout.write('###RESULT ' + _json.dumps({'_id': None, 'ok': False, 'error': str(e)}) + '\n')
            _sys.stdout.flush()
    return 0


def main():
    args = build_parser().parse_args()

    # ★ 2026-11-12：常驻引擎会复用同一进程。上一个可选引擎任务可能把
    #   models/<runtime>/site（另一种 CPython 构建）留在 sys.path，导致后续
    #   MuScriptor 任务 import scipy/numpy 失败（报「scipy 坏了」）。
    #   每个请求进来先清一遍，详见 transcribe_runtime.sanitize_sys_path()。
    try:
        from transcribe_runtime import sanitize_sys_path
        _bad = sanitize_sys_path()
        if _bad and args.mode != "worker":
            print("[清理] 已移除 ABI 不匹配的运行时路径：%s"
                  % "; ".join("%s(cp%s)" % (os.path.basename(os.path.dirname(b["site"])), b["abi"].replace(".", ""))
                              for b in _bad), flush=True)
    except Exception:
        pass

    # 回收上次异常退出（进程被强杀 → finally 没跑）留在系统临时目录里的解码 WAV
    # 与 demucs 声部目录。正常路径下它们都在各自的 finally 里删掉了，这里只兜残留。
    # worker 模式的 stdout 是 ###RESULT 协议，不能掺任何输出，故仅非 worker 模式打印。
    try:
        from audio_io import sweep_stale_temp
        n = sweep_stale_temp()
        if n and args.mode != "worker":
            print("[清理] 回收 %d 项上次遗留的临时文件/目录" % n, flush=True)
    except Exception:
        pass

    if args.mode == "gui":
        return run_gui()

    if args.mode == "probe":
        return cmd_probe()

    if args.mode == "worker":
        return cmd_worker()

    if args.mode == "convert" and not args.input:
        print("[错误] convert 模式需要指定音频文件，例如:")
        print("       python music2midi.py convert 歌曲.mp3")
        return 1

    if args.mode == "separate":
        return cmd_separate(args)

    # 检查指定模式所需依赖
    if not dependencies_ok(args.engine_mode):
        print_deps_help(args.engine_mode)
        return 1

    if args.mode == "convert":
        return cmd_convert(args)
    if args.mode == "batch":
        return cmd_batch(args)
    return 0


if __name__ == "__main__":
    sys.exit(main())